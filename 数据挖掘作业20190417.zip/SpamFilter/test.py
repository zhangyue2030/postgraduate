taniningNum = 3
for i in range(taniningNum):
    print(i)